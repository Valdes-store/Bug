const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "𝗥𝗔𝗣𝗟𝗜𝗠𝗢𝗗𝗦"
global.nama = "𝖷𝖳𝖱𝖫𝖵𝖭𝖥𝖨𝖵𝖤𝖵𝖤𝖱𝖲𝖨𝖮𝖭"
global.ch = 'https://whatsapp.com/channel/0029Vb4xNCE5q08dRIMzC11K'
global.status = true
global.namaowner = '𝖱𝖺𝗉𝗅𝗂𝖬𝗄𝖽𝖽𝖾𝗋𝗌'
//====== [ THEME URL & URL ] ========//
global.thumb = "https://files.catbox.moe/m8c9mz.jpg"
global.thumbnail = 'https://files.catbox.moe/m8c9mz.jpg'
global.Url = '-'
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat", 
    premium: "ᴏɴʟʏ ᴘʀᴇᴍɪᴜᴍ!!!!", 
    responbug: "succes send bug kepada target mohon jeda agar tidak kenon", 
    special: "ᴏɴʟʏ ᴍᴜʀʙᴜɢs sᴘᴇᴄɪᴀʟ!!"
}

global.packname = '𝘩𝘰𝘳𝘴𝘦'
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
